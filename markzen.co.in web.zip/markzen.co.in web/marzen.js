(function(){
var T=[['📱','Reels','3x reach'],['🎯','Meta Ads','4x ROI'],['🔍','Local SEO','Top 3 Google'],['🎬','Video Edit','Viral shorts'],['💡','Strategy','90 day plan'],['🛍️','D2C Sales','5x orders'],['📈','Growth','+320% leads'],['🎨','Branding','New look'],['💬','WhatsApp','Instant leads'],['▶️','YouTube','Subscribers']];
var w=document.getElementById('wall'),h='';
for(var c=0;c<8;c++){var half='';for(var i=0;i<8;i++){var t=T[(c*3+i)%T.length];half+='<div class="tile g'+((c+i)%5+1)+'"><i>'+t[0]+'</i><b>'+t[1]+'</b>'+t[2]+'</div>'}h+='<div class="col" style="animation-duration:'+(55+c*7)+'s">'+half+half+'</div>'}
w.innerHTML=h;
var n=document.querySelector('nav'),b=document.getElementById('mb');
b.addEventListener('click',function(){var o=n.classList.toggle('open');b.setAttribute('aria-expanded',o);b.textContent=o?'✕':'☰'});
n.querySelectorAll('ul a').forEach(function(a){a.addEventListener('click',function(){n.classList.remove('open');b.textContent='☰';b.setAttribute('aria-expanded',false)})});
})();
document.getElementById('f').addEventListener('submit',function(e){
e.preventDefault();var d=new FormData(this);
var t='Hi MarkZen! Name: '+d.get('n')+', Phone: '+d.get('p')+', Service: '+d.get('s')+', Budget: '+d.get('b')+', Message: '+(d.get('m')||'-');
window.open('https://wa.me/917774827696?text='+encodeURIComponent(t),'_blank');
});
setTimeout(function(){var i=document.getElementById('intro');if(i)i.style.display='none'},2200);

(function(){
var nv=document.querySelector('nav');
function sc(){nv.classList.toggle('scrolled',window.scrollY>30)}
window.addEventListener('scroll',sc,{passive:true});sc();
var els=document.querySelectorAll('main section h2,main section .sub,.card,.proj,form');
if(!('IntersectionObserver' in window))return;
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});
els.forEach(function(el,i){el.classList.add('rv');el.style.transitionDelay=((i%4)*80)+'ms';io.observe(el)});
})();

(function(){
if(!window.matchMedia('(hover:hover)').matches)return;
document.querySelectorAll('.card').forEach(function(c){
c.addEventListener('mousemove',function(e){var r=c.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
c.style.setProperty('--mx',x+'px');c.style.setProperty('--my',y+'px');
c.style.setProperty('--ry',((x/r.width-.5)*8)+'deg');c.style.setProperty('--rx',((.5-y/r.height)*8)+'deg')});
c.addEventListener('mouseleave',function(){c.style.setProperty('--rx','0deg');c.style.setProperty('--ry','0deg')});
});
document.querySelectorAll('.btn').forEach(function(b){
b.addEventListener('mousemove',function(e){var r=b.getBoundingClientRect();
b.style.setProperty('--tx',((e.clientX-r.left-r.width/2)*.18)+'px');b.style.setProperty('--ty',((e.clientY-r.top-r.height/2)*.25)+'px')});
b.addEventListener('mouseleave',function(){b.style.setProperty('--tx','0px');b.style.setProperty('--ty','0px')});
});
setTimeout(function(){document.querySelectorAll('.rv').forEach(function(el){el.style.transitionDelay='0ms'})},3500);
if(window.matchMedia('(prefers-reduced-motion:reduce)').matches)return;
var g=document.createElement('div');g.className='cglow';document.body.appendChild(g);
var tx=0,ty=0,x=0,y=0;
window.addEventListener('mousemove',function(e){tx=e.clientX;ty=e.clientY;g.classList.add('on')},{passive:true});
document.addEventListener('mouseleave',function(){g.classList.remove('on')});
(function f(){x+=(tx-x)*.12;y+=(ty-y)*.12;g.style.transform='translate('+x+'px,'+y+'px)';requestAnimationFrame(f)})();
})();

(function(){
var rm=window.matchMedia('(prefers-reduced-motion:reduce)').matches;
var pg=document.createElement('div');pg.className='prog';document.body.appendChild(pg);
function sp(){var h=document.documentElement.scrollHeight-innerHeight;pg.style.transform='scaleX('+(h>0?Math.min(1,scrollY/h):0)+')'}
addEventListener('scroll',sp,{passive:true});sp();
if(rm)return;
document.querySelectorAll('.stats b').forEach(function(b){
var t=b.textContent,n=parseFloat(t);if(isNaN(n))return;var suf=t.slice(String(n).length);b.textContent='0'+suf;
setTimeout(function(){var st=performance.now();(function f(now){var k=Math.min(1,(now-st)/1600),e=1-Math.pow(1-k,3);b.textContent=Math.round(n*e)+suf;if(k<1)requestAnimationFrame(f)})(st)},2800);
});
var gr=document.querySelector('.growth');
if(gr&&matchMedia('(hover:hover)').matches)addEventListener('mousemove',function(e){
gr.style.setProperty('--px',((e.clientX/innerWidth-.5)*-26)+'px');gr.style.setProperty('--py',((e.clientY/innerHeight-.5)*-18)+'px')},{passive:true});
})();

(function(){
var rm=matchMedia('(prefers-reduced-motion:reduce)').matches;if(rm)return;
var cols=['#e50914','#ff6a3d','#ffb347','#ffffff','#25d366'];
function burst(x,y){for(var i=0;i<22;i++){var c=document.createElement('i');c.className='cf';var a=Math.random()*6.283,d=60+Math.random()*110;
c.style.left=x+'px';c.style.top=y+'px';c.style.background=cols[i%cols.length];
c.style.setProperty('--cx',Math.cos(a)*d+'px');c.style.setProperty('--cy',(Math.sin(a)*d-40)+'px');c.style.setProperty('--cr',(Math.random()*720-360)+'deg');
document.body.appendChild(c);setTimeout(function(){c.remove()},1000)}}
document.querySelectorAll('.btn').forEach(function(b){b.addEventListener('click',function(e){
var r=b.getBoundingClientRect(),sz=Math.max(r.width,r.height)*2,s=document.createElement('span');s.className='rip';
s.style.cssText='width:'+sz+'px;height:'+sz+'px;left:'+(e.clientX-r.left-sz/2)+'px;top:'+(e.clientY-r.top-sz/2)+'px';
b.appendChild(s);setTimeout(function(){s.remove()},700);
if(b.classList.contains('red'))burst(e.clientX,e.clientY)})});
var hero=document.querySelector('.hero');
for(var i=0;i<16;i++){var p=document.createElement('span'),z=3+Math.random()*5;p.className='pt';
p.style.cssText='left:'+Math.random()*100+'%;width:'+z+'px;height:'+z+'px;animation-duration:'+(8+Math.random()*10)+'s;animation-delay:'+(2.5+Math.random()*8)+'s;--dx:'+(Math.random()*80-40)+'px';hero.appendChild(p)}
var tr=document.querySelector('.track'),pause=false,dir=1;
if(tr){['mouseenter','touchstart','focusin'].forEach(function(ev){tr.addEventListener(ev,function(){pause=true})});
['mouseleave','touchend'].forEach(function(ev){tr.addEventListener(ev,function(){setTimeout(function(){pause=false},1500)})});
(function f(){if(!pause){tr.scrollLeft+=.5*dir;if(tr.scrollLeft+tr.clientWidth>=tr.scrollWidth-1)dir=-1;else if(tr.scrollLeft<=0)dir=1}requestAnimationFrame(f)})()}
})();